/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class Inicio {

    public static void main(String[] args) throws Exception {
        Coneccion c = new Coneccion();
        c.conexion();
        //c.Metodo("Hola").forEach((String r)->System.out.println(r));
        //List<Relaciones> l = c.Metodo();
        List<Parque> p = c.cercaniaCentralidad();
        Collections.sort(p);
        int par = p.size();
        Parque pl = p.get(par-1);
        /* for (Relaciones relaciones : l) {
            //System.out.println(relaciones.getCior()+"----"+relaciones.getCost()+"-----"+relaciones.getCidst());
            
        }*/
        for (Parque parque : p) {
            System.out.println(parque.getNombre() + "---------" + parque.getCentralidad());
        }
        c.close();
        System.out.println("El mejor Parque Conenectado es: "+ pl.getNombre());
    }

}
