/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Usuario
 */
import java.util.ArrayList;
import java.util.List;
import org.neo4j.driver.AuthTokens;
import org.neo4j.driver.Driver;
import org.neo4j.driver.GraphDatabase;
import org.neo4j.driver.Record;
import org.neo4j.driver.Result;
import org.neo4j.driver.Session;
import org.neo4j.driver.Transaction;
import org.neo4j.driver.TransactionWork;
import static org.neo4j.driver.Values.parameters;

public class Coneccion {

    private Driver driver;

    public void conexion() {
        String uri = "bolt://localhost:7687";
        String user = "neo4j";
        String password = "malki";
        driver = GraphDatabase.driver(uri, AuthTokens.basic(user, password));
    }

    public void close() throws Exception {
        driver.close();
    }

    public List<Relaciones> Metodo() {
        List<Relaciones> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");

                    for (Record r : result.list()) {
                        Relaciones l = new Relaciones();
                        l.setCior(r.get(0).asString());
                        l.setCidst(r.get("dest").asString());
                        Double costo = r.get("costo").asDouble();
                        l.setCost(costo);
                        list.add(l);
                        /*System.out.print(r.get(0));
                        System.out.print(r.get("dest"));
                        System.out.print(r.get("costo"));
                        System.out.println("");*/
                    }
                    return null;
                }
            });
            // System.out.println(greeting);
        }
        return list;
    }

    public List<Lugar> listar(String param) {
        List<Lugar> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    Result result = tx.run("MATCH(n:" + param + ") return n.name AS m");
                    for (Record r : result.list()) {
                        Relaciones l = new Relaciones();
                        Lugar lugar = new Lugar();
                        lugar.setNombre(r.get(0).asString());
                        list.add(lugar);

                    }
                    return null;
                }
            });
            // System.out.println(greeting);
        }
        return list;
    }

    public List<Parque> cercaniaCentralidad() {
        List<Parque> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    Result res = tx.run("CALL gds.alpha.closeness.stream({nodeProjection: 'Parque',relationshipProjection: 'LINK'})YIELD nodeId, centrality "
                            + "RETURN gds.util.asNode(nodeId).name AS user, centrality");
                    for (Record r : res.list()) {
                        Parque p = new Parque();
                        p.setNombre(r.get(0).asString());
                        p.setCentralidad(r.get("centrality").asDouble());
                        list.add(p);
                    }
                    return null;
                }
            });
            // System.out.println(greeting);
        }

        return list;
    }

    public List<Parque> cercaniaCentralidadS(String lugar) {
        List<Parque> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    Result res = tx.run("CALL gds.alpha.closeness.stream({nodeProjection: '" + lugar + "',relationshipProjection: 'LINK'})YIELD nodeId, centrality "
                            + "RETURN gds.util.asNode(nodeId).name AS user, centrality");
                    for (Record r : res.list()) {
                        Parque p = new Parque();
                        p.setNombre(r.get(0).asString());
                        p.setCentralidad(r.get("centrality").asDouble());
                        list.add(p);
                    }
                    return null;
                }
            });
            // System.out.println(greeting);
        }

        return list;
    }

    public List<Lugar> cercaniaCentralidadLugar(String lugar) {
        List<Lugar> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    Result res = tx.run("CALL gds.alpha.closeness.stream({nodeProjection: '" + lugar + "',relationshipProjection: 'LINK'})YIELD nodeId, centrality "
                            + "RETURN gds.util.asNode(nodeId).name AS user, centrality");
                    for (Record r : res.list()) {
                        Lugar p = new Lugar();
                        p.setNombre(r.get(0).asString());
                        p.setCentralidad(r.get("centrality").asDouble());
                        list.add(p);
                    }
                    return null;
                }
            });
            // System.out.println(greeting);
        }

        return list;
    }

    public List<Parque> costoUniforme(String lugar) {
        List<Parque> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    Result res = tx.run("MATCH (start:Parque {name: 'Terminal Terrestre Quitumbe'}), (end:Parque {name: 'Parque La Alameda'})"
                            + "CALL gds.alpha.shortestPath.stream({"
                            + "  nodeProjection: 'Parque',"
                            + "  relationshipProjection: {"
                            + "    ROAD: {"
                            + "      type: 'LINK',"
                            + "      properties: 'cost',"
                            + "      orientation: 'UNDIRECTED'"
                            + "    }"
                            + "  },"
                            + "  startNode: start,"
                            + "  endNode: end,"
                            + "  relationshipWeightProperty: 'cost'"
                            + "})"
                            + "YIELD nodeId, cost "
                            + "RETURN gds.util.asNode(nodeId).name AS name, cost");
                    for (Record r : res.list()) {
                        Parque p = new Parque();
                        p.setNombre(r.get(0).asString());
                        p.setCentralidad(r.get("cost").asDouble());
                        list.add(p);
                    }
                    return null;
                }
            });
            // System.out.println(greeting);
        }

        return list;
    }

    public List<Lugar> costoUniformeLugar(String clase, String lugar1, String lugar2) {
        List<Lugar> list = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    Result res = tx.run("MATCH (start:" + clase + " {name: '" + lugar1 + "'}), (end:" + clase + " {name: '" + lugar2 + "'})"
                            + "CALL gds.alpha.shortestPath.stream({"
                            + "  nodeProjection: '" + clase + "',"
                            + "  relationshipProjection: {"
                            + "    ROAD: {"
                            + "      type: 'LINK',"
                            + "      properties: 'cost',"
                            + "      orientation: 'UNDIRECTED'"
                            + "    }"
                            + "  },"
                            + "  startNode: start,"
                            + "  endNode: end,"
                            + "  relationshipWeightProperty: 'cost'"
                            + "})"
                            + "YIELD nodeId, cost "
                            + "RETURN gds.util.asNode(nodeId).name AS name, cost");
                    for (Record r : res.list()) {
                        Lugar p = new Lugar();
                        p.setNombre(r.get(0).asString());
                        p.setCosto(r.get("cost").asDouble());
                        list.add(p);
                    }
                    return null;
                }
            });
            // System.out.println(greeting);
        }

        return list;
    }

    public Lugar vecinosComunes(String clase, String lugar1, String lugar2) {
        Lugar lugar = new Lugar();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    Result res = tx.run("MATCH (p1:" + clase + " {name: '" + lugar1 + "'})"
                            + " MATCH (p2:" + clase + " {name: '" + lugar2 + "'})"
                            + " RETURN gds.alpha.linkprediction.commonNeighbors(p1, p2) AS score");
                    int num = res.single().get(0).asInt();
                    lugar.setVecino(num);
                    return null;
                }
            });
            // System.out.println(greeting);
        }
        return lugar;
    }

    public List<LugarComunidad> propagacionDeEtiquetas(String grafico) {
        List<LugarComunidad> lugaresComunidad = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    Result res = tx.run("CALL gds.labelPropagation.stream('" + grafico + "') "
                            + "YIELD nodeId, communityId AS Community "
                            + "RETURN gds.util.asNode(nodeId).name AS name, Community ");

                    for (Record r : res.list()) {
                        LugarComunidad lugarComunidad = new LugarComunidad();
                        lugarComunidad.setNombre(r.get(0).asString());
                        lugarComunidad.setCominidad(r.get("Community").asInt());
                        lugaresComunidad.add(lugarComunidad);
                    }
                    return null;
                }

                // System.out.println(greeting);
            });
        }
        return lugaresComunidad;
    }

    public PersonasParquesLugaresTuristicos algoritmoANNParques() {
        List<PersonasParquesLugaresTuristicos> lugaresParquesLugaresTuristicoses = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    Result res = tx.run("MATCH (p:Persona)-[:LIKES]->(Parque) "
                            + "WITH {item:id(p), categories: collect(id(Parque))} AS userData "
                            + "WITH collect(userData) AS data "
                            + "CALL gds.alpha.ml.ann.stream({\n"
                            + "   nodeProjection: '*',\n"
                            + "   relationshipProjection: '*',\n"
                            + "   data: data,\n"
                            + "   algorithm: 'jaccard',\n"
                            + "   similarityCutoff: 0.1,\n"
                            + "   concurrency: 1\n"
                            + " })"
                            + "YIELD item1, item2, similarity "
                            + "return gds.util.asNode(item1).name AS from, gds.util.asNode(item2).name AS to, similarity "
                            + "ORDER BY similarity DESC ");

                    for (Record r : res.list()) {
                        PersonasParquesLugaresTuristicos parquesLugaresTuristicos = new PersonasParquesLugaresTuristicos();
                        parquesLugaresTuristicos.setNombreP1(r.get(0).asString());
                        parquesLugaresTuristicos.setNombreP2(r.get(1).asString());
                        parquesLugaresTuristicos.setSimilaridad(r.get(2).asDouble());
                        lugaresParquesLugaresTuristicoses.add(parquesLugaresTuristicos);
                    }
                    return null;
                }

                // System.out.println(greeting);
            });
        }

        return lugaresParquesLugaresTuristicoses.get(0);
    }

    public PersonasParquesLugaresTuristicos algoritmoANNLugaresTuristicos() {
        List<PersonasParquesLugaresTuristicos> lugaresParquesLugaresTuristicoses = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    Result res = tx.run("MATCH (p:Persona)-[:LIKES]->(LugarTuristico) "
                            + "WITH {item:id(p), categories: collect(id(LugarTuristico))} AS userData "
                            + "WITH collect(userData) AS data "
                            + "CALL gds.alpha.ml.ann.stream({\n"
                            + "   nodeProjection: '*',\n"
                            + "   relationshipProjection: '*',\n"
                            + "   data: data,\n"
                            + "   algorithm: 'jaccard',\n"
                            + "   similarityCutoff: 0.1,\n"
                            + "   concurrency: 1\n"
                            + " })"
                            + "YIELD item1, item2, similarity "
                            + "return gds.util.asNode(item1).name AS from, gds.util.asNode(item2).name AS to, similarity "
                            + "ORDER BY similarity DESC ");

                    for (Record r : res.list()) {
                        PersonasParquesLugaresTuristicos parquesLugaresTuristicos = new PersonasParquesLugaresTuristicos();
                        parquesLugaresTuristicos.setNombreP1(r.get(0).asString());
                        parquesLugaresTuristicos.setNombreP2(r.get(1).asString());
                        parquesLugaresTuristicos.setSimilaridad(r.get(2).asDouble());
                        lugaresParquesLugaresTuristicoses.add(parquesLugaresTuristicos);
                    }
                    return null;
                }

                // System.out.println(greeting);
            });
        }
        System.out.println(lugaresParquesLugaresTuristicoses.get(0).getSimilaridad());
        return lugaresParquesLugaresTuristicoses.get(0);

    }

    public List<String> obtenerParques(String nombrePersona) {
        List<String> parques = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    Result res = tx.run(" MATCH (Person{name:'" + nombrePersona + "'})-[:LIKES]->(Parque) Return Parque.name as nombre");

                    for (Record r : res.list()) {
                        String nombreParque = r.get("nombre").asString();
                        parques.add(nombreParque);
                    }
                    return null;
                }

                // System.out.println(greeting);
            });
        }

        return parques;
    }

    public List<String> obtenerLugares(String nombrePersona) {
        List<String> lTuristicos = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    Result res = tx.run(" MATCH (Person{name:'" + nombrePersona + "'})-[:LIKES]->(LugarTuristico) Return LugarTuristico.name as nombre");

                    for (Record r : res.list()) {
                        String nombreParque = r.get("nombre").asString();
                        lTuristicos.add(nombreParque);
                    }
                    return null;
                }

                // System.out.println(greeting);
            });
        }

        return lTuristicos;
    }

    public void insertarPersona(String nombrePersona, int id) {
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    //Result res2 = tx.run(" MATCH (Person{name:'"+nombrePersona+"'})-[:LIKES]->(LugarTuristico) Return LugarTuristico.name as nombre");  
                    Result res = tx.run("CREATE (:Persona{ id: '" + id + "', name:'" + nombrePersona + "'})");
                    return null;
                }

                // System.out.println(greeting);
            });
        }
    }

    public void insertarRelacionANN(String nombrePersona, String nombreLugar, String tipo) {

        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    //Result res2 = tx.run(" MATCH (Person{name:'"+nombrePersona+"'})-[:LIKES]->(LugarTuristico) Return LugarTuristico.name as nombre");  
                    Result res = tx.run("MATCH (ini:Persona{name:'" + nombrePersona + "'}),(des:" + tipo + "{name:'" + nombreLugar + "'}) CREATE (ini)-[:LIKES]->(des); ");
                    return null;
                }

                // System.out.println(greeting);
            });
        }

    }

    public List<String> comprovarANN(String nombrePersona, String tipo) {
        List<String> lugares = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    //Result res2 = tx.run(" MATCH (Person{name:'"+nombrePersona+"'})-[:LIKES]->(LugarTuristico) Return LugarTuristico.name as nombre");  
                    //Result res = tx.run("MATCH (ini:Persona{name:'"+nombrePersona+"'}),(des:"+tipo+"{name:'"+nombreLugar+"'}) CREATE (ini)-[:LIKES]->(des); ");  
                    Result res2 = tx.run("match (n:Persona{name:'" + nombrePersona + "'})-[:LIKES]->(p:" + tipo + ") return p.name AS nombre");
                    if (res2.list().isEmpty()) {
                         System.out.println("NO TIENE RELACIONES ESTA PERSONA"); 
                    } else {
                        for (Record r : res2.list()) {
                            String nombre = r.get("nombre").asString();
                            lugares.add(nombre);
                        }
                    }
                    return null;
                }
                // System.out.println(greeting);
            });
        }
        return lugares;
    }

    
    
    public void similarity(){
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    //Result res2 = tx.run(" MATCH (Person{name:'"+nombrePersona+"'})-[:LIKES]->(LugarTuristico) Return LugarTuristico.name as nombre");  
                    //Result res = tx.run("MATCH (ini:Persona{name:'"+nombrePersona+"'}),(des:"+tipo+"{name:'"+nombreLugar+"'}) CREATE (ini)-[:LIKES]->(des); ");  
                    Result res2 = tx.run("MATCH (p:Persona)-[:LIKES]->(lugaresturisticos)\n" +
                                            " WITH {item:id(p), categories: collect(id(lugaresturisticos))} AS userData\n" +
                                            " WITH collect(userData) AS data\n" +
                                            " CALL gds.alpha.ml.ann.write({\n" +
                                            "  nodeProjection: '*',\n" +
                                            "  relationshipProjection: '*',\n" +
                                            "  algorithm: 'jaccard',\n" +
                                            "  data: data,\n" +
                                            "  similarityCutoff: 0.1,\n" +
                                            "  showComputations: true,\n" +
                                            "  concurrency: 1\n" +
                                            " })\n" +
                                            " YIELD nodes, similarityPairs, writeRelationshipType, writeProperty, min, max, mean, p95\n" +
                                            " RETURN nodes, similarityPairs, writeRelationshipType, writeProperty, min, max, mean, p95"); 
                    return null;
                    
                }
                // System.out.println(greeting);
            });
        }
    } 
    
    
    
    public List<String> recomendaciones(String nombrePersona){  
        List<String> lugares = new ArrayList<>();
        try (Session session = driver.session()) {
            String greeting = session.writeTransaction(new TransactionWork<String>() {
                @Override
                public String execute(Transaction tx) {
                    //Result result = tx.run("MATCH(n:Node)-[r:REL]->(d:Node) return n.tag AS m, d.tag AS dest, r.cost AS costo");
                    //Result res2 = tx.run(" MATCH (Person{name:'"+nombrePersona+"'})-[:LIKES]->(LugarTuristico) Return LugarTuristico.name as nombre");  
                    //Result res = tx.run("MATCH (ini:Persona{name:'"+nombrePersona+"'}),(des:"+tipo+"{name:'"+nombreLugar+"'}) CREATE (ini)-[:LIKES]->(des); ");  
                    Result res2 = tx.run("MATCH (p:Persona {name:'"+nombrePersona+"'})-[:SIMILAR]->(other),\n" +
                                         "       (other)-[:LIKES]->(lugarturistico)\n" +
                                         " WHERE not((p)-[:LIKES]->(lugarturistico))\n" +
                                         " RETURN lugarturistico.name AS lugarturistico, count(*) AS count\n" +
                                         " ORDER BY count DESC ");   
                    
                        for (Record r : res2.list()) {
                            String nombre = r.get("lugarturistico").asString(); 
                            System.out.println(nombre);
                            lugares.add(nombre);
                        }
                    
                    return null;
                    
                }
                // System.out.println(greeting);
            });
        }
        return lugares;
    }
}
