/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Usuario
 */
public class Parque implements Comparable<Parque>{
    public String nombre;
    public double centralidad;

    public Parque() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getCentralidad() {
        return centralidad;
    }

    public void setCentralidad(double centralidad) {
        this.centralidad = centralidad;
    }

    @Override
    public int compareTo(Parque t) {
        if (centralidad < t.centralidad) {
                return -1;
            }
            if (centralidad > t.centralidad) {
                return 1;
            }
            return 0;
    }
  
}
