/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Usuario
 */
public class Lugar implements Comparable<Lugar>{
    public String nombre;
    public Double centralidad;
    public Double costo;
    public int vecino;

    public Lugar() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Double getCentralidad() {
        return centralidad;
    }

    public void setCentralidad(Double centralidad) {
        this.centralidad = centralidad;
    }

    public Double getCosto() {
        return costo;
    }

    public void setCosto(Double costo) {
        this.costo = costo;
    }

    public int getVecino() {
        return vecino;
    }

    public void setVecino(int vecino) {
        this.vecino = vecino;
    }
    
    

    @Override
    public int compareTo(Lugar t) {
        if (centralidad < t.centralidad) {
                return -1;
            }
            if (centralidad > t.centralidad) {
                return 1;
            }
            return 0;
    }
    
    
   
    
    
}
