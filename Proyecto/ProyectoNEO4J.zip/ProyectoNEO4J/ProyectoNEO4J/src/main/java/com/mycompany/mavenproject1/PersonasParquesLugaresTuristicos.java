/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author ALEX
 */
public class PersonasParquesLugaresTuristicos {
    private String nombreP1; 
    private String nombreP2; 
    private Double similaridad; 

    public String getNombreP1() {
        return nombreP1;
    }

    public void setNombreP1(String nombreP1) {
        this.nombreP1 = nombreP1;
    }

    public String getNombreP2() {
        return nombreP2;
    }

    public void setNombreP2(String nombreP2) {
        this.nombreP2 = nombreP2;
    }

    public Double getSimilaridad() {
        return similaridad;
    }

    public void setSimilaridad(Double similaridad) {
        this.similaridad = similaridad;
    }   
}
