/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.ComboBox;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Usuario
 */
public class Vecinos extends javax.swing.JInternalFrame {
    //String seleccion;
    List<Lugar> vecinoComunes;
    String sel;
    /**
     * Creates new form Vecinos
     */
    public Vecinos(String lugar, String origen) {
        initComponents();
        DefaultTableModel modelo = (DefaultTableModel) tbllista.getModel();
        for (int i = modelo.getRowCount() - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
        Coneccion con = new Coneccion();
        con.conexion();
        List<Lugar> vecinos = new ArrayList<>();
        System.out.println(lugar + origen);
        if (lugar.equalsIgnoreCase("Parque")) {
            cbxlugares.setSelectedIndex(1);
            List<Lugar> list = con.listar(lugar);
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                Lugar lug = con.vecinosComunes(lugar, origen, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
            System.out.println(vecinos.size());
        } else if (lugar.equalsIgnoreCase("LugarTuristico")) {
            cbxlugares.setSelectedIndex(0);
            List<Lugar> list = con.listar(lugar);
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                Lugar lug = con.vecinosComunes(lugar, origen, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (lugar.equalsIgnoreCase("Iglesia")) {
            cbxlugares.setSelectedIndex(2);
            List<Lugar> list = con.listar(lugar);
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                Lugar lug = con.vecinosComunes(lugar, origen, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (lugar.equalsIgnoreCase("Hospital")) {
            cbxlugares.setSelectedIndex(3);
            List<Lugar> list = con.listar(lugar);
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                Lugar lug = con.vecinosComunes(lugar, origen, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (lugar.equalsIgnoreCase("Bombero")) {
            cbxlugares.setSelectedIndex(4);
            List<Lugar> list = con.listar(lugar);
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                Lugar lug = con.vecinosComunes(lugar, origen, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (lugar.equalsIgnoreCase("Policia")) {
            cbxlugares.setSelectedIndex(5);
            List<Lugar> list = con.listar(lugar);
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                Lugar lug = con.vecinosComunes(lugar, origen, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (lugar.equalsIgnoreCase("Escuela")) {
            cbxlugares.setSelectedIndex(6);
            List<Lugar> list = con.listar(lugar);
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                Lugar lug = con.vecinosComunes(lugar, origen, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (lugar.equalsIgnoreCase("CentroEducativo")) {
            cbxlugares.setSelectedIndex(7);
            List<Lugar> list = con.listar(lugar);
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                Lugar lug = con.vecinosComunes(lugar, origen, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (lugar.equalsIgnoreCase("CentroMedico")) {
            cbxlugares.setSelectedIndex(8);
            List<Lugar> list = con.listar(lugar);
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                Lugar lug = con.vecinosComunes(lugar, origen, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (lugar.equalsIgnoreCase("CentrodeEstimulacion")) {
            cbxlugares.setSelectedIndex(9);
            List<Lugar> list = con.listar(lugar);
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                Lugar lug = con.vecinosComunes(lugar, origen, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        }
        Object lista[] = new Object[3];
        for (Lugar pro : vecinos) {
            lista[0] = pro.getNombre();
            //lista[1] = pro.getCosto();
            modelo.addRow(lista);
        }
        tbllista.setModel(modelo);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        cbxtodos = new javax.swing.JComboBox<>();
        cbxlugares = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbllista = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        setClosable(true);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Lugares Cercanos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Serif", 3, 36))); // NOI18N

        cbxtodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxtodosActionPerformed(evt);
            }
        });

        cbxlugares.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "LugaresTuristicos", "Parques", "Iglesias", "Hospitales", "Bomberos", "Policias", "Escuelas", "CentrosEducativos", "Centros Medicos", "CentrosDeEstimulacion" }));
        cbxlugares.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxlugaresActionPerformed(evt);
            }
        });

        jLabel1.setText("Lugar que Desea Visitar");

        tbllista.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "Lugares Mas Cercanos"
            }
        ));
        jScrollPane1.setViewportView(tbllista);

        jButton1.setText("Buscar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(cbxlugares, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(68, 68, 68)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbxtodos, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbxtodos, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbxlugares, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(143, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbxlugaresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxlugaresActionPerformed
        // TODO add your handling code here:
        
        cbxtodos.removeAllItems();
        DefaultTableModel modelo = (DefaultTableModel) tbllista.getModel();
        for (int i = modelo.getRowCount() - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
        String seleccion = (String)cbxlugares.getSelectedItem();
        Coneccion con = new Coneccion();
        con.conexion();
        System.out.println(seleccion+"*********************");
        
        //List<Lugar> list = con.listar(seleccion);
        if (seleccion.equalsIgnoreCase("Parques")) {
            //cbxlugares.setSelectedIndex(1);
            
            List<Lugar> list = con.listar("Parque");
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                
            }
           
        } else if (seleccion.equalsIgnoreCase("LugaresTuristicos")) {
            //cbxlugares.setSelectedIndex(0);
            
            List<Lugar> list = con.listar("LugarTuristico");
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                
            }
        } else if (seleccion.equalsIgnoreCase("Iglesias")) {
            //cbxlugares.setSelectedIndex(2);
            List<Lugar> list = con.listar("Iglesia");
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                
            }
        } else if (seleccion.equalsIgnoreCase("Hospitales")) {
            //cbxlugares.setSelectedIndex(3);
            List<Lugar> list = con.listar("Hospital");
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                
            }
        } else if (seleccion.equalsIgnoreCase("Bomberos")) {
            //cbxlugares.setSelectedIndex(4);
            List<Lugar> list = con.listar("Bombero");
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                
            }
        } else if (seleccion.equalsIgnoreCase("Policias")) {
            //cbxlugares.setSelectedIndex(5);
            List<Lugar> list = con.listar("Policia");
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                
            }
        } else if (seleccion.equalsIgnoreCase("Escuelas")) {
            //cbxlugares.setSelectedIndex(6);
            List<Lugar> list = con.listar("Escuela");
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                
            }
        } else if (seleccion.equalsIgnoreCase("CentrosEducativos")) {
            //cbxlugares.setSelectedIndex(7);
            List<Lugar> list = con.listar("CentroEducativo");
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                
            }
        } else if (seleccion.equalsIgnoreCase("Centros Medicos")) {
            //cbxlugares.setSelectedIndex(8);
            List<Lugar> list = con.listar("CentroMedico");
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                
            }
        } else if (seleccion.equalsIgnoreCase("CentrosDeEstimulacion")) {
            //cbxlugares.setSelectedIndex(9);
            List<Lugar> list = con.listar("CentrodeEstimulacion");
            for (Lugar lugar1 : list) {
                cbxtodos.addItem(lugar1.getNombre());
                
            }
        }
        try {
            con.close();
        } catch (Exception ex) {
            Logger.getLogger(Vecinos.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_cbxlugaresActionPerformed

    private void cbxtodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxtodosActionPerformed
        // TODO add your handling code here:
       /* 
        String st = (String)cbxlugares.getSelectedItem();
        String lg = (String)cbxtodos.getSelectedItem();
        
        System.out.println(st+"*************"+lg);
        DefaultTableModel modelo = (DefaultTableModel) tbllista.getModel();
        for (int i = modelo.getRowCount() - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
        Coneccion con = new Coneccion();
        con.conexion();
        List<Lugar> vecinos = new ArrayList<>();
        if (st.equalsIgnoreCase("Parques")) {
            List<Lugar> list = con.listar("Parque");
            for (Lugar lugar1 : list) {
                Lugar lug = con.vecinosComunes("Parque", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
            System.out.println(vecinos.size());
        } else if (st.equalsIgnoreCase("LugaresTuristicos")) {
            List<Lugar> list = con.listar("LugarTuristico");
            for (Lugar lugar1 : list) {
                Lugar lug = con.vecinosComunes("LugarTuristico", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("Iglesias")) {
            
            List<Lugar> list = con.listar("Iglesia");
            for (Lugar lugar1 : list) {
                
                Lugar lug = con.vecinosComunes("Iglesia", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("Hospitales")) { 
            List<Lugar> list = con.listar("Hospital");
            for (Lugar lugar1 : list) {
                Lugar lug = con.vecinosComunes("Hospital", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("Bomberos")) {
            
            List<Lugar> list = con.listar("Bombero");
            for (Lugar lugar1 : list) {
                
                Lugar lug = con.vecinosComunes("Bombero", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("Policias")) {
            
            List<Lugar> list = con.listar("Policia");
            for (Lugar lugar1 : list) {
                
                Lugar lug = con.vecinosComunes("Policia", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("Escuelas")) {
            
            List<Lugar> list = con.listar("Escuela");
            for (Lugar lugar1 : list) {
                
                Lugar lug = con.vecinosComunes("Escuela", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("CentrosEducativos")) {
            
            List<Lugar> list = con.listar("CentroEducativo");
            for (Lugar lugar1 : list) {
               
                Lugar lug = con.vecinosComunes("CentroEducativo", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("Centros Medicos")) {
           
            List<Lugar> list = con.listar("CentroMedico");
            for (Lugar lugar1 : list) {
                
                Lugar lug = con.vecinosComunes("CentroMedico", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("CentrosDeEstimulacion")) {
            
            List<Lugar> list = con.listar("CentrodeEstimulacion");
            for (Lugar lugar1 : list) {
                
                Lugar lug = con.vecinosComunes("CentrodeEstimulacion", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        }
        
        Object lista[] = new Object[3];
        for (Lugar pro : vecinos) {
            lista[0] = pro.getNombre();
            //lista[1] = pro.getCosto();
            modelo.addRow(lista);
        }
        tbllista.setModel(modelo);
        */
    }//GEN-LAST:event_cbxtodosActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        String st = (String)cbxlugares.getSelectedItem();
        String lg = (String)cbxtodos.getSelectedItem();
        System.out.println(st+"*************"+lg);
        DefaultTableModel modelo = (DefaultTableModel) tbllista.getModel();
        for (int i = modelo.getRowCount() - 1; i >= 0; i--) {
            modelo.removeRow(i);
        }
        Coneccion con = new Coneccion();
        con.conexion();
        List<Lugar> vecinos = new ArrayList<>();
        if (st.equalsIgnoreCase("Parques")) {
            List<Lugar> list = con.listar("Parque");
            for (Lugar lugar1 : list) {
                Lugar lug = con.vecinosComunes("Parque", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
            System.out.println(vecinos.size());
        } else if (st.equalsIgnoreCase("LugaresTuristicos")) {
            List<Lugar> list = con.listar("LugarTuristico");
            for (Lugar lugar1 : list) {
                Lugar lug = con.vecinosComunes("LugarTuristico", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("Iglesias")) {
            
            List<Lugar> list = con.listar("Iglesia");
            for (Lugar lugar1 : list) {
                
                Lugar lug = con.vecinosComunes("Iglesia", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("Hospitales")) { 
            List<Lugar> list = con.listar("Hospital");
            for (Lugar lugar1 : list) {
                Lugar lug = con.vecinosComunes("Hospital", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("Bomberos")) {
            
            List<Lugar> list = con.listar("Bombero");
            for (Lugar lugar1 : list) {
                
                Lugar lug = con.vecinosComunes("Bombero", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("Policias")) {
            
            List<Lugar> list = con.listar("Policia");
            for (Lugar lugar1 : list) {
                
                Lugar lug = con.vecinosComunes("Policia", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("Escuelas")) {
            
            List<Lugar> list = con.listar("Escuela");
            for (Lugar lugar1 : list) {
                
                Lugar lug = con.vecinosComunes("Escuela", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("CentrosEducativos")) {
            
            List<Lugar> list = con.listar("CentroEducacionDeNinos");
            for (Lugar lugar1 : list) {
               
                Lugar lug = con.vecinosComunes("CentroEducacionDeNinos", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("Centros Medicos")) {
           
            List<Lugar> list = con.listar("Centro");
            for (Lugar lugar1 : list) {
                
                Lugar lug = con.vecinosComunes("Centro", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        } else if (st.equalsIgnoreCase("CentrosDeEstimulacion")) {
            
            List<Lugar> list = con.listar("CentroEstimulacionTemprana");
            for (Lugar lugar1 : list) {
                
                Lugar lug = con.vecinosComunes("CentroEstimulacionTemprana", lg, lugar1.getNombre());
                if (lug.getVecino() == 1) {
                    vecinos.add(lugar1);
                }
            }
        }
        
        Object lista[] = new Object[3];
        for (Lugar pro : vecinos) {
            lista[0] = pro.getNombre();
            //lista[1] = pro.getCosto();
            modelo.addRow(lista);
        }
        tbllista.setModel(modelo);
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbxlugares;
    private javax.swing.JComboBox<String> cbxtodos;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbllista;
    // End of variables declaration//GEN-END:variables
}
